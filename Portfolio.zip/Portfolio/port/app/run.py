from flask import Flask, render_template as rd, url_for

app = Flask(__name__)

@app.route("/") #define a rota da minha página
def index():
  return rd("home.html")

@app.route("/experiencia") #define a rota da minha página
def exp():
  return rd("expe.html")

@app.route("/projetos")
def proj():
  return rd("proj.html")

if __name__ == "__main__":
  app.run(debug = True)
